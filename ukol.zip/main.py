if __name__ == "__main__":
    with open("autor.txt", "r") as f:
        autor = f.readline()

    print("Jednoduchý program na hodinu APR")
    print(f"by {autor}")
    print("<----------- [ Soubor ] ----------->")
    print("Zadejte cestu k textu pro analýzu:")
    soubor = input()
    print("<----------- [ Analýza Textu ] ----------->")
    print("Probíhá analýza...")
    try:
        with open(soubor, "r", encoding="utf-8") as f:
            text = f.read()
    except UnicodeDecodeError as e:
        print(f"Chyba při načítání souboru: {e}")
        exit()
    
    words = []
    sentences = []
    sentence = ""
    word = ""

    for character in text:
        if character.isalnum() or character in "'-":
            word += character
            sentence += character
        else:
            if word:
                words.append(word)
                word = ""
            
            if character in ".!?":
                sentence += character
                sentences.append(sentence.strip())
                sentence = ""
            elif not character.isspace():
                sentence += character
            else:
                sentence += character
    
    if sentence:
        sentences.append(sentence.strip())
    
    if word:
        words.append(word)
    
    count_of_characters_with_spaces = len(text)
    count_of_characters_without_spaces = len([character for character in text if not character.isspace()])

    count_of_words = len(words)
    count_of_sentences = len(sentences)

    max_sentence = ""
    max_length = 0
    for sentence in sentences:
        if len(sentence) > max_length:
            max_length = len(sentence)
            max_sentence = sentence
    
    repeated_words = {}
    for word in words:
        repeated_words[word] = repeated_words.get(word, 0) + 1
    
    average_of_length_words = count_of_characters_without_spaces / count_of_words

    repeated_characters = {}
    for character in text:
        if character.isalpha():
            repeated_characters[character] = repeated_characters.get(character, 0) + 1
    
    last_repeated_character = max(repeated_characters, key=repeated_characters.get)

    only_one_words = len([word for word, count in repeated_words.items() if count == 1])

    repeated_length = {}
    for word in words:
        length = len(word)
        repeated_length[length] = repeated_length.get(length, 0) + 1
    
    repeated_output = {}
    for length, count in repeated_length.items():
        repeated_length[length] = count
    
    print(f"- Celkový počet znaků (včetně mezer): {count_of_characters_with_spaces}")
    print(f"- Celkový počet znaků (bez mezer): {count_of_characters_without_spaces}")
    print(f"- Celkový počet slov: {count_of_words}")
    print(f"- Počet vět: {count_of_sentences}")
    print(f"- Věta s největším počtem slov: {max_sentence}")
    print(f"- Průměrná délka slov: {average_of_length_words}")
    print(f"- Nejčastější písmeno: {last_repeated_character}")
    print(f"- Počet slov, která se objevují pouze jednou: {only_one_words}")
    print(f"- Četnost slov podle délky:")
    for length, count in sorted(repeated_length.items()):
        print(f"Délka {length}: {'*' * count}")